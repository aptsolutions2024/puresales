<!-- Bootstrap bundle JS -->
  <script src="assets/js/bootstrap.bundle.min.js"></script>
  <!--plugins-->
  <!--<script src="assets/js/jquery.min.js"></script>-->
    <script src="assets/js/jquery_3_7_1.min.js"></script>
  <script src="assets/plugins/simplebar/js/simplebar.min.js"></script>
  <script src="assets/plugins/metismenu/js/metisMenu.min.js"></script>
  <!--<script src="assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js"></script>-->
  <script src="assets/js/pace.min.js"></script>
  <script src="assets/plugins/chartjs/js/Chart.min.js"></script>
  <script src="assets/plugins/chartjs/js/Chart.extension.js"></script>
  <script src="assets/plugins/apexcharts-bundle/js/apexcharts.min.js"></script>
  

  <!--app-->
  <script src="assets/js/app.js"></script>
  <script src="assets/js/index.js"></script>
     <!--<script src="assets/plugins/datatable/js/jquery.dataTables.min.js"></script>-->
   <script src="assets/js/datatables.min.js"></script>
     
  <!--<script src="assets/plugins/datatable/js/dataTables.bootstrap5.min.js"></script>-->
  <script src="assets/js/table-datatable.js"></script>
  <script>
    new PerfectScrollbar(".best-product")
 </script>

