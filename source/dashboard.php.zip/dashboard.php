<?php
session_start();
?><!doctype html>
<html lang="en" class="light-theme">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
   <title>Pure Sales - Dashboard</title>
  
  
<?php include 'sidebar.php'; ?>
       <!--start content-->
          <main class="page-content">
              
            <div class="row row-cols-1 row-cols-lg-2 row-cols-xl-2 row-cols-xxl-4">
              <div class="col">
                <div class="card overflow-hidden radius-10">
                    <div class="card-body p-2">
                     <div class="d-flex align-items-stretch justify-content-between radius-10 overflow-hidden">
                      <div class="w-50 p-3 bg-light-pink">
                        <p>Total Cylinders</p>
                        <h4 class="text-primary">1,000</h4>
                      </div>
                      <div class="w-50 bg-pink p-3">
                         <p class="mb-3 text-white">+ 80% <i class="bi bi-arrow-up"></i></p>
                         <div id="chart1"></div>
                      </div>
                    </div>
                  </div>
                </div>
               </div>
               <div class="col">
                <div class="card overflow-hidden radius-10">
                    <div class="card-body p-2">
                     <div class="d-flex align-items-stretch justify-content-between radius-10 overflow-hidden">
                      <div class="w-50 p-3 bg-light-success">
                        <p>Cylinder Delivered</p>
                        <h4 class="text-primary">800</h4>
                      </div>
                      <div class="w-50 bg-success p-3">
                         <p class="mb-3 text-white">50% <i class="bi bi-arrow-down"></i></p>
                         <div id="chart2"></div>
                      </div>
                    </div>
                  </div>
                </div>
               </div>
               <div class="col">
                <div class="card overflow-hidden radius-10">
                    <div class="card-body p-2">
                     <div class="d-flex align-items-stretch justify-content-between radius-10 overflow-hidden">
                      <div class="w-50 p-3 bg-light-orange">
                        <p>Filled Cylinders</p>
                        <h4 class="text-primary">50</h4>
                      </div>
                      <div class="w-50 bg-orange p-3">
                         <p class="mb-3 text-white">10% <i class="bi bi-arrow-up"></i></p>
                         <div id="chart3"></div>
                      </div>
                    </div>
                  </div>
                </div>
               </div>
               <div class="col">
                <div class="card overflow-hidden radius-10">
                    <div class="card-body p-2">
                     <div class="d-flex align-items-stretch justify-content-between radius-10 overflow-hidden">
                      <div class="w-50 p-3 bg-light-primary">
                        <p>Empty Cylinders</p>
                        <h4 class="text-primary">150</h4>
                      </div>
                      <div class="w-50 bg-primary p-3">
                         <p class="mb-3 text-white">20% <i class="bi bi-arrow-up"></i></p>
                         <div id="chart4"></div>
                      </div>
                    </div>
                  </div>
                </div>
               </div>
            </div><!--end row-->

			<div class="row">
              <div class="col-12 col-lg-6 col-xl-6 col-xxl-4 d-flex">
                <div class="card radius-10 bg-transparent shadow-none w-100">
                  <div class="card-body p-0">
                    <div class="card radius-10">
                      <div class="card-body">
                        <div class="d-flex align-items-center">
                           <h6 class="mb-0">O2</h6>
                           
                        </div>
                        <div class="row row-cols-1 row-cols-md-2 mt-3 g-3">
                          <div class="col">
                            <div class="by-device-container">
                              <canvas id="chart5"></canvas>
                            </div>
                          </div>
                          <div class="col">
                            <div class="">
                              <ul class="list-group list-group-flush">
                                <li class="list-group-item d-flex align-items-center justify-content-between border-0">
                                  <i class="bi bi-tablet-landscape-fill me-2 text-primary"></i> <span>Delivered - </span> <span>75%</span>
                                </li>
                                <li class="list-group-item d-flex align-items-center justify-content-between border-0">
                                  <i class="bi bi-phone-fill me-2 text-primary-2"></i> <span>Empty - </span> <span>10%</span>
                                </li>
                                <li class="list-group-item d-flex align-items-center justify-content-between border-0">
                                  <i class="bi bi-display-fill me-2 text-primary-3"></i> <span>Filled - </span> <span>15%</span>
                                </li>
                              </ul>
                             </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    </div>
                    </div>
                    </div>
					<div class="col-12 col-lg-6 col-xl-6 col-xxl-4 d-flex">
                <div class="card radius-10 bg-transparent shadow-none w-100">
                  <div class="card-body p-0">
					<div class="card radius-10">
                      <div class="card-body">
                        <div class="d-flex align-items-center">
                           <h6 class="mb-0">CO2</h6>
                           
                        </div>
                        <div class="row row-cols-1 row-cols-md-2 mt-3 g-3">
                          <div class="col">
                            <div class="by-device-container">
                              <canvas id="chartnew5"></canvas>
                            </div>
                          </div>
                          <div class="col">
                            <div class="">
                              <ul class="list-group list-group-flush">
                                <li class="list-group-item d-flex align-items-center justify-content-between border-0">
                                  <i class="bi bi-tablet-landscape-fill me-2 text-primary"></i> <span>Delivered - </span> <span>60%</span>
                                </li>
                                <li class="list-group-item d-flex align-items-center justify-content-between border-0">
                                  <i class="bi bi-phone-fill me-2 text-primary-2"></i> <span>Empty - </span> <span>15%</span>
                                </li>
                                <li class="list-group-item d-flex align-items-center justify-content-between border-0">
                                  <i class="bi bi-display-fill me-2 text-primary-3"></i> <span>Filled - </span> <span>15%</span>
                                </li>
                              </ul>
                             </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                  </div>
                </div>
              </div>
              
              
            </div><!--end row-->

            
            


          </main>
       <!--end page main-->

       <!--start overlay-->
        <div class="overlay nav-toggle-icon"></div>
       <!--end overlay-->

       <!--Start Back To Top Button-->
		     <a href="javaScript:;" class="back-to-top"><i class='bx bxs-up-arrow-alt'></i></a>
       <!--End Back To Top Button-->

       <!--start switcher-->
       

  </div>
  <!--end wrapper-->

<?php include 'footer.php'; ?>
  
</body>

</html>