<?php
error_reporting(0);
session_start();
include 'class/timeZone.php';
include 'class/user.php';
$user = new user();

$gasId=$_REQUEST['gasId'];
$cust_id=$_REQUEST['cust_id'];
$type=$_REQUEST['type'];
if($gasId!='')
{
$res=$user->getCylinderByGasIdFactory($gasId);
$total=sizeof($res);
 if($total!=0){
foreach($res as $cylinder){
   
?>
<option value="<?=$cylinder['cy_id'];?>"><?=$cylinder['cy_no'];?></option>

<?php 
} } else{ ?>
<option value="">No cylinder available.</option>
<?php } }
else if($cust_id!='')
{
 $res=$user->getCylinderByGasIdCustomer($cust_id);  
 $i=1;
 $total=sizeof($res);
 if($total!=0){
foreach($res as $cylinder){
   
?>
<!--<option value="<?=$cylinder['cy_id'].' - '.$cylinder['chln_id'];?>"><?=$cylinder['cy_no'].' - '.$cylinder['chln_no'];?></option>-->
<tr>
<th scope="row"><input type="checkbox" name="cylinderRetR[]" id="cylinderRetR<?=$cylinder['cy_id'];?>" value="<?=$cylinder['cy_id'];?>"></th>
<td><?=$cylinder['cy_no'];?></td>
<td><?=$cylinder['chln_no'];?></td>
<td>
<select class="form-select" id="status<?=$cylinder['cy_id'];?>" name="status[]">
<option value="1">Empty</option>
<option value="2">Filled</option>
<option value="3">Damaged</option>
<option value="4">Lost</option>
</select>
</td>
</tr>
<?php $i++; } 
}else{ ?>
<tr><td colspan="5" style="text-align: center;color: #ff0000;">No Cylinders found.</td></tr>
<?php }} ?>
