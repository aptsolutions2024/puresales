<?php 
error_reporting(0);
  $id = base64_decode($_GET['ID']);
  include 'class/user.php';
  $user = new user();
  $getGas=$user->getAllGases();
  //print_r($getcust);
  ?>
  