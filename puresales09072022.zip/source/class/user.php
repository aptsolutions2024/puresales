<?php

class user
{
	public $connection;
    
	public function __construct() {
        $this->connection = new PDO('mysql:dbname=PureSales;host=localhost;charset=utf8','PureSales','PureSales@1234');	
		$this->connection->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
		$this->connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		}
     function loginDetailsById($loginId){
        $qs = "SELECT * FROM login_master where id ='$loginId'";
        $stmt = $this->connection->prepare($qs);
        $stmt->execute();
        $rows = $stmt->fetch();
        return $rows;
    }
      function loginDetails($email,$password){
        $qs = "SELECT * FROM login_master where username ='$email' and password ='$password'";
        $stmt = $this->connection->prepare($qs);
        $stmt->execute();
        $rows = $stmt->fetch(PDO::FETCH_ASSOC);
        return $rows;
    }
      function loginCountDetails($email,$password){
        $qs = "SELECT * FROM login_master where username ='$email' and password ='$password'";
        $stmt = $this->connection->prepare($qs);
        $stmt->execute();
        $rows = $stmt->rowCount();
        return $rows;
    }
    
    /*------------------------------------------Customer-----------------------------------*/
    
	function countCustomer($phone_no) {
        $query = "select * from customer where mobile='$phone_no'";
        $stmt = $this->connection->prepare($query);
		$stmt->execute();		
		$num = $stmt->rowCount();
		return $num;	       
    }
	function insertCustomer($name,$phone_no,$email,$gst_no,$address,$curr) {
        $query = "INSERT INTO `customer`(`name`, `mobile`, `email`, `address`, `gstno`, `add_date`, `update_date`) VALUES ('$name','$phone_no','$email','$address','$gst_no','$curr','$curr')";
        $stmts = $this->connection->prepare($query);         
		$stmts->execute();	       
    }
     function updateCustomer($editId,$name,$phone_no,$email,$gst_no,$address,$curr) {
        $query = "UPDATE `customer` SET `name`='$name',`mobile`='$phone_no',`email`='$email',`address`='$address',`gstno`='$gst_no',`update_date`='$curr' WHERE cust_id='$editId'";
        $stmts = $this->connection->prepare($query);         
		$stmts->execute();	       
    }
	function getAllCustomers() {
       $query = "select * from customer order by cust_id desc ";
        $stmt = $this->connection->prepare($query);
		$stmt->execute();
		$fetch = $stmt->fetchAll(); 		
        return $fetch;
    }
	
  function getCustomerbyId($id) {
       $query = "select * from customer where cust_id='$id'";
        $stmt = $this->connection->prepare($query);
    $stmt->execute();
    $fetch = $stmt->fetch(PDO::FETCH_ASSOC);    
        return $fetch;
    }
	
	function deleteCustomers($id) {
       $query = "DELETE FROM `customer` WHERE cust_id='$id' ";
        $stmt = $this->connection->prepare($query);
		$stmt->execute();
		return $stmt;
    }
    
	
    
    /*------------------------------------------Cylinders-----------------------------------*/
    
    function countCylinder($cy_no) {
        $query = "select * from Cylinders where cy_no='$cy_no'";
        $stmt = $this->connection->prepare($query);
		$stmt->execute();		
		$num = $stmt->rowCount();
		return $num;	       
    }
	function insertCylinder($cust_id,$gas_id,$cy_no) {
        $query = "INSERT INTO `Cylinders`(`gas_id`, `cust_id`, `cy_no`) VALUES ('$gas_id','$cust_id','$cy_no')";
        $stmts = $this->connection->prepare($query);         
		$stmts->execute();	       
    }
     function updateCylinder($editId,$cust_id,$gas_id,$cy_no) {
        $query = "UPDATE `Cylinders` SET `gas_id`='$gas_id',`cust_id`='$cust_id',`cy_no`='$cy_no' WHERE cy_id='$editId'";
        $stmts = $this->connection->prepare($query);         
		$stmts->execute();	       
    }
	function getAllCylinder() {
       $query = "select * from Cylinders order by cy_id desc ";
        $stmt = $this->connection->prepare($query);
		$stmt->execute();
		$fetch = $stmt->fetchAll(); 		
        return $fetch;
    }
   function getCylinderbyId($id) {
       $query = "select * from Cylinders where cy_id='$id'";
        $stmt = $this->connection->prepare($query);
        $stmt->execute();
        $fetch = $stmt->fetch(PDO::FETCH_ASSOC);    
        return $fetch;
    }
    function getCylinderByGasIdFactory($gasId) {
       $query = "select * from Cylinders where gas_id='$gasId' and cust_id='1' and filled_status=2 order by cy_id desc ";
        $stmt = $this->connection->prepare($query);
		$stmt->execute();
		$fetch = $stmt->fetchAll(); 		
        return $fetch;
    }
    function getRefillCylinders() {
       $query = "select * from Cylinders where cust_id='1' and filled_status=1 order by cy_no asc ";
        $stmt = $this->connection->prepare($query);
		$stmt->execute();
		$fetch = $stmt->fetchAll(); 		
        return $fetch;
    }
    function getCylinderByGasIdCustomer($cust_id) {
        $query = "select max(tdc.chln_id) as chln_id,tdc.id,tdc.cy_no, mdc.chln_no,tdc.cy_id,tdc.chln_id from tran_del_chln tdc inner join mast_del_chln mdc on tdc.chln_id = mdc.chln_id where cy_id in (select cy_id from Cylinders where cust_id = '$cust_id') group by cy_id";
        $stmt = $this->connection->prepare($query);
		$stmt->execute();
		$fetch = $stmt->fetchAll(); 		
        return $fetch;
    }
    function getDeliveredCylinder($cust_id,$chln_date,$chln_id) {
         $query = "select tdc.id,tdc.cy_no, mdc.chln_no,tdc.cy_id,tdc.chln_id from tran_del_chln tdc inner join mast_del_chln mdc on tdc.chln_id = mdc.chln_id where mdc.cust_id='$cust_id' and (tdc.ret_chln_no='' OR ISNULL (tdc.ret_chln_no)) and tdc.chln_id!='$chln_id' and mdc.chln_date < '$chln_date'";
       $stmt = $this->connection->prepare($query);
		$stmt->execute();
		$fetch = $stmt->fetchAll(); 		
        return $fetch;
    }
    
    /*------------------------------Gases--------------------*/
    function getAllGases() {
       $query = "select * from Gases order by gas_id desc ";
        $stmt = $this->connection->prepare($query);
		$stmt->execute();
		$fetch = $stmt->fetchAll(); 		
        return $fetch;
    }
    function getGasesbyId($id) {
       $query = "select * from Gases where gas_id='$id'";
        $stmt = $this->connection->prepare($query);
        $stmt->execute();
        $fetch = $stmt->fetch(PDO::FETCH_ASSOC);    
        return $fetch;
    }
    
    /*------------------------------Mast_Del_Chln--------------------*/
    
    function insertMastDelChln($login_id,$cust_id,$challan_no,$chln_date,$vehicle_no,$cy_action,$gas_id,$cylinderR,$cylinderRetR,$curr)
    {
    
    $query = "INSERT INTO `mast_del_chln`(`cust_id`, `chln_no`, `vehicle_no`, `chln_date`, `created_by`, `created_date`) VALUES ('$cust_id','$challan_no','$vehicle_no','$chln_date','$login_id','$curr')";
    $stmts = $this->connection->prepare($query);         
    $stmts->execute();	  
    $chln_id = $this->connection->lastInsertId();
    
    foreach($cylinderR as $row){
	$cyno=$this->getCylinderbyId($row);
    $query1 = "INSERT INTO `tran_del_chln`(`chln_id`,`cy_id`,`cy_no`,`action`) VALUES ('$chln_id','$row','$cyno[cy_no]','1')";
    $stmts1 = $this->connection->prepare($query1);         
    $stmts1->execute();
    
    $query1 = "UPDATE `Cylinders` SET `cust_id`='$cust_id' WHERE cy_id='$row'";
    $stmts1 = $this->connection->prepare($query1);         
    $stmts1->execute();
    }
    
    $cylinderRetRs=explode(",",$cylinderRetR);
    foreach($cylinderRetRs as $key => $row){
    $details=explode("#",$row);  
    //print_r($details);
    $cy_id=$details[0];
	$status=trim($details[1]);
		 
		 
	$cyno=$this->getCylinderbyId($cy_id);
    
    $query1 = "UPDATE `tran_del_chln` SET `ret_chln_no`='$challan_no',`ret_status`='$status',`ret_chln_id`='$chln_id' WHERE cy_id='$cy_id'";
    $stmts1 = $this->connection->prepare($query1);         
    $stmts1->execute();
    
    $query1 = "UPDATE `Cylinders` SET `cust_id`='1' , `filled_status`='$status' WHERE cy_id='$cy_id'";
    $stmts1 = $this->connection->prepare($query1);         
    $stmts1->execute();
    }
    
    
    }
    
    function updateDelChln($cust_id,$challan_id,$chln_date,$vehicle_no,$cy_action,$gas_id,$cylinderR,$cylinderRetR)
    {
        $query1 = "UPDATE `mast_del_chln` SET `vehicle_no`='$vehicle_no',`chln_date`='$chln_date' WHERE cust_id='$cust_id' and chln_id='$challan_id'";
        $stmts1 = $this->connection->prepare($query1);         
        $stmts1->execute();
        
        
        foreach($cylinderR as $row){
    	$cyno=$this->getCylinderbyId($row);
        $query1 = "INSERT INTO `tran_del_chln`(`chln_id`,`cy_id`,`cy_no`,`action`) VALUES ('$challan_id','$row','$cyno[cy_no]','1')";
        $stmts1 = $this->connection->prepare($query1);         
        $stmts1->execute();
        
        $query1 = "UPDATE `Cylinders` SET `cust_id`='$cust_id' WHERE cy_id='$row'";
        $stmts1 = $this->connection->prepare($query1);         
        $stmts1->execute();
        }
        
        $cylinderRetRs=explode(",",$cylinderRetR);
        foreach($cylinderRetRs as $key => $row){
        $details=explode("#",$row);  
        echo "<pre>";print_r($details);
        $tranid=$details[0];
    	$status=trim($details[1]);
    	$cyId=trim($details[2]);
    	$retchln_no=trim($details[3]);
    		 
    		 
    	$cyno=$this->getCylinderbyId($cyId);
    	$cylinderDetails=$this->getCylinderByChallanId($challan_id);
    	$retchln_no=$cylinderDetails['chln_no'];
        
        //$query1 = "UPDATE `tran_del_chln` SET `ret_chln_no`='$challan_id',`ret_status`='$status',`ret_chln_id`='$challan_id' WHERE cy_id='$cyId'";
        $query1 = "UPDATE `tran_del_chln` SET `ret_chln_no`='$retchln_no',`ret_status`='$status',`ret_chln_id`='$challan_id' WHERE cy_id='$cyId' and id='$tranid'";
        $stmts1 = $this->connection->prepare($query1);         
        $stmts1->execute();
        
        $query1 = "UPDATE `Cylinders` SET `cust_id`='1' , `filled_status`='$status' WHERE cy_id='$cyId'";
        $stmts1 = $this->connection->prepare($query1);         
        $stmts1->execute();
        }
        
         
    
        
    }
    
    
  function getCustomersCylinderList($cust_id) {
      if($cust_id=='1')
      {
          $action=2;
      }else{
         $action=1; 
      }
       $query = "select tdc.cy_no,mdc.chln_no,tdc.filled_status from tran_del_chln tdc,mast_del_chln mdc where tdc.chln_id=mdc.chln_id and mdc.cust_id='$cust_id' and tdc.action='$action' and (ISNULL(tdc.ret_chln_no) OR trim(tdc.ret_chln_no=''))  order by tdc.id desc ";
        $stmt = $this->connection->prepare($query);
		$stmt->execute();
		$fetch = $stmt->fetchAll(); 		
        return $fetch;
    } 
    function getCylinderByChallanId($chln_id) {
       $query = "select * from mast_del_chln where chln_id='$chln_id' order by chln_id desc ";
        $stmt = $this->connection->prepare($query);
		$stmt->execute();
		$fetch = $stmt->fetch(); 		
        return $fetch;
    } 
    function getCylinderByCustId($custId) {
       $query = "select * from mast_del_chln where cust_id='$custId' order by chln_id desc ";
        $stmt = $this->connection->prepare($query);
		$stmt->execute();
		$fetch = $stmt->fetchAll(); 		
        return $fetch;
    } 
    function getCustomersCylinderByChallanDeli($chln_id) {
       $query = "select * from tran_del_chln where chln_id='$chln_id'  order by id desc ";
        $stmt = $this->connection->prepare($query);
		$stmt->execute();
		$fetch = $stmt->fetchAll(); 		
        return $fetch;
    } 
    function getCustomersCylinderByChallanRet($chln_id) {
       $query = "select tdc.*,mdc.chln_no from tran_del_chln tdc inner join mast_del_chln mdc On mdc.chln_id=tdc.chln_id where ret_chln_id='$chln_id'  order by id desc ";
        $stmt = $this->connection->prepare($query);
		$stmt->execute();
		$fetch = $stmt->fetchAll(); 		
        return $fetch;
    }
    function getCylinderByChallanRet($chln_id) {
       $query = "select * from tran_del_chln where ret_chln_id='$chln_id'  order by id desc ";
        $stmt = $this->connection->prepare($query);
		$stmt->execute();
		$fetch = $stmt->fetchAll(); 		
        return $fetch;
    }
    
    
    /*------------------------------Refill_Del_Chln--------------------*/
    
    function insertRefillDelChln($login_id,$refill_date,$refill_document,$cylinderR,$curr)
    {
        foreach($cylinderR as $cyID){
        	$cyno=$this->getCylinderbyId($cyID);
        	$CYNO .=rtrim($cyno['cy_no'].',');
        	$query1 = "UPDATE `Cylinders` SET `cust_id`='1' , `filled_status`='2' WHERE cy_id='$cyID'";
            $stmts1 = $this->connection->prepare($query1);         
            $stmts1->execute();
        }
        $CYNO =rtrim($CYNO, ',');
        $cyid=implode(",",$cylinderR);
        $query1 = "INSERT INTO `refill`(`refill_document`, `refill_date`, `cy_no`, `cy_id`, `created_by`, `created_date`) VALUES ('$refill_document','$refill_date','$CYNO','$cyid','$login_id','$curr')";
        $stmts1 = $this->connection->prepare($query1);         
        $stmts1->execute();
        
    
    }
    function updateRefillDelChln($editId,$login_id,$refill_date,$refill_document,$cylinderR,$curr)
    {
        foreach($cylinderR as $cyID){
        	$cyno=$this->getCylinderbyId($cyID);
        	$CYNO .=rtrim($cyno['cy_no'].',');
        	$query1 = "UPDATE `Cylinders` SET `cust_id`='1' , `filled_status`='2' WHERE cy_id='$cyID'";
            $stmts1 = $this->connection->prepare($query1);         
            $stmts1->execute();
        }
        $CYNO =rtrim($CYNO, ',');
        $cyid=implode(",",$cylinderR);
        $query1 = "UPDATE `refill` SET `refill_document`='$refill_document',`refill_date`='$refill_date',`cy_no`='$CYNO',`cy_id`='$cyid',`updated_by`='$login_id',`updated_date`='$curr' WHERE `id`='$editId'";
        $stmts1 = $this->connection->prepare($query1);         
        $stmts1->execute();
        
    
    }
    function getAllRefillCylinders() {
       $query = "select * from refill order by refill_document,refill_date desc ";
        $stmt = $this->connection->prepare($query);
		$stmt->execute();
		$fetch = $stmt->fetchAll(); 		
        return $fetch;
    }
    function getRefillDatabyId($id) {
       $query = "select * from refill where id='$id'";
        $stmt = $this->connection->prepare($query);
		$stmt->execute();
		$fetch = $stmt->fetch(PDO::FETCH_ASSOC); 		
        return $fetch;
    }
    function deleteRefillCylinder($loginId,$cyNos,$cyId,$refill_id,$deletecyId,$curr) {
       $query = "UPDATE `refill` SET `cy_no`='$cyNos',`cy_id`='$cyId',`updated_by`='$loginId',`updated_date`='$curr' WHERE `id`='$refill_id' ";
        $stmt = $this->connection->prepare($query);
		$stmt->execute();
		
		$query1 = "UPDATE `Cylinders` SET `cust_id`='1' , `filled_status`='1' WHERE cy_id='$deletecyId'";
        $stmts1 = $this->connection->prepare($query1);         
        $stmts1->execute();
        
        
    }
    function getTrackingCylinders() {
       $query = "select * from rep_cylinder order by id";
        $stmt = $this->connection->prepare($query);
		$stmt->execute();
		$fetch = $stmt->fetchAll(PDO::FETCH_ASSOC); 		
        return $fetch;
    }
    
    
  
}
?>