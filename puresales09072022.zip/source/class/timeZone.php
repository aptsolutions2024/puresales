<?php

	date_default_timezone_set("Asia/Kolkata");
	$currdateZone = date("Y-m-d");
	$currTimeZone =  date("H:i:s");
	 $currentDateTime = $currdateZone." ".$currTimeZone;

?>