<?php
error_reporting(0);
session_start();
include 'class/timeZone.php';
include 'class/user.php';
$user = new user();

$gasId=$_REQUEST['gasId'];

$res=$user->getRefillCylinders();
$total=sizeof($res);
 if($total!=0){
foreach($res as $cylinder){
   
?>
<option value="<?=$cylinder['cy_id'];?>"><?=$cylinder['cy_no'];?></option>

<?php 
} } else { ?>
<option value="">No cylinder available.</option>
<?php } ?>
