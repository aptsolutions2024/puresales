<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(0);
session_start();
include 'class/timeZone.php';
include 'class/user.php';
$user = new user();
//print_r($_POST);die;
$cust_id='1';
$gas_id=$_REQUEST['gas_id'];
$cy_no=$_REQUEST['cy_no'];

$editId=$_REQUEST['editId'];
$action=$_REQUEST['action'];


$count=$user->countCylinder($cy_no);
if($count=='0')
{ 
if($action!='update'){			

$res=$user->insertCylinder($cust_id,$gas_id,$cy_no);
$_SESSION['addcymsg']='001';
echo "<script>window.location.href='/add-cylinder';</script>";exit();
}else if($action=='update')
{
$res=$user->updateCylinder($editId,$cust_id,$gas_id,$cy_no);

$_SESSION['addcymsg']='003';
echo "<script>window.location.href='/add-cylinder';</script>";exit();	
}
}
 else
{
$_SESSION['addcymsg']='002';
echo "<script>window.location.href='/add-cylinder';</script>";exit();	
} 

?>